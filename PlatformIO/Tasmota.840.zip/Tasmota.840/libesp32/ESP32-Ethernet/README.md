# Ethernet Arduino Library for ESP32

See https://github.com/espressif/arduino-esp32/issues/3554#issuecomment-596902806

