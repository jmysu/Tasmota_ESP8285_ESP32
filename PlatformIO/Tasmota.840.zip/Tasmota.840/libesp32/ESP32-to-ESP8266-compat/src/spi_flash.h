//
// Compat with ESP32
//
// TODO: Port it to ESP32
