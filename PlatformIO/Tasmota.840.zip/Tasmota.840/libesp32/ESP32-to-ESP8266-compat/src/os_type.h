#pragma once
#include "esp8266-compat.h"
#include <stdbool.h>
#include <stdint.h>
typedef uint16 uint16_t;
typedef double real64_t;
